<header class="p-3 bg-dark text-white">
<?php if(auth()->guard()->check()): ?>
<ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
   <li><a href="#" class="nav-link px-2 text-white">Veículos</a></li>
   <li><a href="#" class="nav-link px-2 text-white">Clientes</a></li>
   <li><a href="#" class="nav-link px-2 text-white">Registros</a></li> 
</ul>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <div class="text-end">
        <a href="#"> Início </a>   
        <a href="#" class="btn btn-outline-light"> Login </a>
    </div>
<?php endif; ?>
</header><?php /**PATH C:\xampp\htdocs\estacione\resources\views/layouts/menu.blade.php ENDPATH**/ ?>