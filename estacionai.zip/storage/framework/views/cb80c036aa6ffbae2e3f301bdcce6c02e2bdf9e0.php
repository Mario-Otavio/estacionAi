<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laravel</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table class="table">
    <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr> 
    <td><?php echo e($veiculo->id); ?> </td>
     <td>    <?php echo e($veiculo->placa); ?></td>
     <td>
        <form action="POST">
            <a class="btn btn-info" href="<?php echo e(route('veiculo.listar', $veiculo->id)); ?>"> Detalhes </a>
            <a class="btn btn-primary" href="<?php echo e(route('veiculo.edit', $veiculo->id)); ?>"> Editar </a>
            <button type="submit" class="btn btn-danger">
                <?php echo csrf_field(); ?> 
                <?php echo method_field('destroy'); ?>
                Delete
            </button>
        </form>
     </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html><?php /**PATH C:\Users\Murilo Mafra\Documents\estacione\resources\views/veiculos/veiculos.blade.php ENDPATH**/ ?>